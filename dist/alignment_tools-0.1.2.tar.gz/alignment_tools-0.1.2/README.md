## 📦 PyPI
- For documentation refer to 

https://alignment-tools.readthedocs.io/en/latest/alignment_tools.html

You can install this package via pip:

```bash
pip install alignment_tools
```

or first clone the package and then

```
pip install -e .


```

