## 📦 PyPI

You can install this package via pip:

```bash
pip install alignment_tools
```

or first clone the package and then

```
pip install -e .


```

